import React from 'react';
const Explore = () => (
  <div className="container">
    <h2>Explorer les espaces</h2>
    <p>Ici s'affichera la liste des espaces filtrables (catégories, prix, horaires...)</p>
  </div>
);
export default Explore;