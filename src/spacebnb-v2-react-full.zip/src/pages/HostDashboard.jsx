import React from 'react';
const HostDashboard = () => (
  <div className="container">
    <h2>Mon tableau de bord (Hôte)</h2>
    <p>Ajouter un espace, gérer les disponibilités et les réservations.</p>
  </div>
);
export default HostDashboard;