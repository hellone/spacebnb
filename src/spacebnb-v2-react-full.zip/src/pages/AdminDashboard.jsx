import React from 'react';
const AdminDashboard = () => (
  <div className="container">
    <h2>Interface Admin</h2>
    <p>Validation des annonces, modération et gestion des utilisateurs.</p>
  </div>
);
export default AdminDashboard;