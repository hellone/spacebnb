import React from 'react';
import { signInWithPopup } from 'firebase/auth';
import { auth, provider } from '../firebase';

const Login = () => {
  const handleLogin = async () => {
    try {
      await signInWithPopup(auth, provider);
    } catch (error) {
      alert(error.message);
    }
  };

  return (
    <div className="container">
      <h2>Connexion</h2>
      <button onClick={handleLogin}>Connexion avec Google</button>
    </div>
  );
};

export default Login;